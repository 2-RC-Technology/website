from django.contrib import admin
from django.urls import path, include

admin.site.site_header = "2ARC Admin"
admin.site.site_title = "2ARC Admin Portal"
admin.site.index_title = "Welcome to 2ARC Portal"

urlpatterns = [
    path('admin/', admin.site.urls),
    path("",include('myapp.urls'))
]