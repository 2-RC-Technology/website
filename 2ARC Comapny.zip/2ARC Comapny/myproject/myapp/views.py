from django.shortcuts import render
from myapp.models import Product, Contact
from datetime import datetime
from django.contrib import messages

def home(request):
    products = Product.objects.all()
    return render(request, 'index.html', {'products': products})

def product_detail(request, product_id):
    product = Product.objects.get(pk=product_id)
    return render(request, 'product_detail.html', {'product': product})

def category_products(request, category_id):
   products = Product.objects.filter(category_id=category_id)
   return render(request, 'category_products.html', {'products': products})

    #return HttpResponse("this is about page") 

def about(request):
    return render(request,"about.html")

def services(request):
    return render(request,"service.html")
    
    #return HttpResponse("this is services page")

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc, date = datetime.today())
        contact.save()
        messages.success(request, 'Your message has been sent.')
    return render(request,"contact.html")
    